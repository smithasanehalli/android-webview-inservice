package com.example.myapplication;

import android.content.Intent;

import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        WebView mywebview = (WebView) findViewById(R.id.webView);
        WebView wv = ServiceWithWebView.wv;


       // mywebview.loadUrl("http://www.google.com");

        // Log.d("MYAPP", "canDrawOverlays :" +Settings.canDrawOverlays(MainActivity.this));
        if (Build.VERSION.SDK_INT >= 23 && (!Settings.canDrawOverlays(MainActivity.this))) {

            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, 1234);
        } else {
            Intent intent = new Intent(MainActivity.this, ServiceWithWebView.class);
            startService(intent);
        }
        Log.d("MYAPP","wv"+wv);
        Log.d("MYAPP","status"+ServiceWithWebView.status);

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopService(new Intent(MainActivity.this, ServiceWithWebView.class));
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
        stopService(new Intent(MainActivity.this, ServiceWithWebView.class));
    }
}
