package com.example.myapplication;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Binder;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class ServiceWithWebView extends Service {

    // This is the object that receives interactions from clients.
    private final IBinder mBinder = new LocalBinder();
    public static WebView wv;
    public static boolean status;
    WindowManager mWindowManager;
    LinearLayout view;

    public WebView getWv() {
        return wv;
    }

    public class LocalBinder extends Binder {
        ServiceWithWebView getService() {
            return ServiceWithWebView.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("MYAPP", "service onCreate :" );
        //WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        status = true;
        mWindowManager = (WindowManager)getSystemService(Context.WINDOW_SERVICE);

        //Build Params
        WindowManager.LayoutParams mWindowParams = new WindowManager.LayoutParams();
        mWindowParams.gravity = Gravity.TOP | Gravity.LEFT;
        //mWindowParams.x = ( x - mDragPointX + mXOffset );
        //mWindowParams.y = ( y - mDragPointY + mYOffset );

        DisplayMetrics metrics = new DisplayMetrics();
        mWindowManager.getDefaultDisplay().getMetrics(metrics);
        //mWindowParams.horizontalMargin = (float)getAbsoluteLeft() / (float)metrics.widthPixels;

        mWindowParams= new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);

        mWindowParams.format = PixelFormat.TRANSLUCENT;
        mWindowParams.windowAnimations = 0;

        view = new LinearLayout(this);
        view.setLayoutParams(new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT));

        wv = new WebView(this);
     /*   wv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));*/
        //view.addView(wv);
        //wv.loadUrl("http://google.com");

        //mWindowManager.addView(view, mWindowParams);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean stopService(Intent name) {
        // TODO Auto-generated method stub
        wv.destroy();
        mWindowManager.removeView(view);
        return super.stopService(name);

    }
}